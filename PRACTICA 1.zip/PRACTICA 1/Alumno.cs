class Alumno
{
    private string nombre;

    public string Nombre
    {
        get { return nombre; }   
        set { nombre = value; } 
    }
    public  Alumno ()
    {

    }

}


﻿using System;

namespace PRACTICA_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno a = new Alumno();
            a.Nombre = "Elsa";
            Console.WriteLine(a.Nombre);
        }
    }
}
